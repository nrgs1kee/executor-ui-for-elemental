﻿using Elemental;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Elemental
{
    public partial class LoadingWindow : Window
    {
        private bool isLoadingComplete = false;

        public LoadingWindow()
        {
            InitializeComponent();
            Loaded += LoadingWindow_Loaded;
        }

        private async void LoadingWindow_Loaded(object sender, RoutedEventArgs e)
        {
            if (isLoadingComplete)
                return;

            isLoadingComplete = true;

            StartEllipsisAnimation();

            await SimulateLoading();

            var mainWindow = new MainWindow();
            mainWindow.Show();

            this.Close();
        }

        private async Task SimulateLoading()
        {
            int totalSteps = 100;
            for (int i = 0; i <= totalSteps; i++)
            {
                progressBar.Value = i;
                await Task.Delay(30);
            }
        }

        private void StartEllipsisAnimation()
        {
            var animation = new DoubleAnimation
            {
                From = 0,
                To = 1,
                Duration = new Duration(TimeSpan.FromMilliseconds(500)),
                AutoReverse = true,
                RepeatBehavior = RepeatBehavior.Forever
            };

            ellipsis.BeginAnimation(OpacityProperty, animation);
        }
    }
}
