﻿using Elemental;
using System.Windows;

namespace Elemental
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            var loadingWindow = new LoadingWindow();
            loadingWindow.Show();
        }
    }
}
